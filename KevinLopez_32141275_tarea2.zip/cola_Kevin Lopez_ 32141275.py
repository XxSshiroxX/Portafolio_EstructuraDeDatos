#Kevin Lopez -> 32141275
class Queue:
    def __init__(self):
        self.q = []

    def is_empty(self):
        return len(self.q) == 0

    def size(self):
        return len(self.q)

    def display(self):
        print(" -> ".join(map(str, self.q)))


# A)
class ColaEntradaDoble(Queue):
    def enqueue_inicio(self, x):
        # Agregar al inicio
        self.q.insert(0, x)

    def enqueue_final(self, x):
        # Agregar al final
        self.q.append(x)

    def dequeue(self):
        if not self.is_empty():
            return self.q.pop(0)


# C)
class ColaConPrioridad(Queue):
    def enqueue(self, x, prioridad):
        # x es el nombre del elemento y prioridad el numero que indica la prioridad del mismo. Siendo que mientras menor el numero, mayor la prioridad.
        self.q.append([prioridad, x])
        # Se ordena por prioridad para que el primer elemento sea siempre el de mayor prioridad, y se facilite el sacarlo con un pop
        self.q.sort(key=lambda item: item[0])

    def dequeue(self):
        # Este saca primero el de mayor prioridad,
        if not self.is_empty():
            #retorna solo el nombre en lugar de la lista entera
            return self.q.pop(0)[1]

    def display(self):
        # Este tambien muestra la prioridad
        print(" ".join([f"{x[1]}(P{x[0]})" for x in self.q]))


if __name__ == "__main__":
    print("A) Concierto con entradas premiun")
    concierto = ColaEntradaDoble()
    # Personas con entrada normal entran normalmente a la final
    concierto.enqueue_inicio("Kevin")  
    concierto.enqueue_inicio("Eduardo")
    # Personas con entrada premiun entran por delante
    concierto.enqueue_final("Victor") 
    concierto.enqueue_final("Manuel")  
    
    concierto.display()
    print("Sale:", concierto.dequeue())
    concierto.display()
    print("No. Personas", concierto.size())

    print("\nC) Sala de emergencias de un hospital que da prioridad dependiendo de la gravedad del caso")
    pq = ColaConPrioridad()
    pq.enqueue("Jhon: Quemadura de primer grado", 3)  
    pq.enqueue("El Brayan: Multiples heridas por apuñalamiento e impactos de bala (Pistola 9mm)", 1)  
    pq.enqueue("Karen: Fractura en la pierna derecha", 2)
    pq.display()
    print(pq.q)
    print("Sale:", pq.dequeue())
    pq.display()
    print("No. Pacientes:", pq.size())
